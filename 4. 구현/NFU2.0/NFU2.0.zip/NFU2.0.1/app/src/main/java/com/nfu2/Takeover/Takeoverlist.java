package com.nfu2.Takeover;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nfu2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class Takeoverlist extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<TakeoverInfo> arrayListTO;
    public FirebaseDatabase database;
    public DatabaseReference databaseReferenceTO;
    private DatabaseReference mDatabaseRef;
    private Button btn_createtakeover;

    long now = System.currentTimeMillis();
    Date mDate = new Date(now);
    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyyMMdd");
    private String ntime = simpleDateFormat.format(mDate)+"0000";
    private long nowtime = Long.parseLong(ntime);
    private int position=0;
    private int count=0;
    public String patientkey;
    public String patientName;
    public String nursekey = ((TakeoverPList) TakeoverPList.context_main).pkey; // 간호사 키 연결

    public String tcode, tname, tage, troom, tsex;

    // 상단 환자 정보
    private TextView t_code;
    private TextView t_name;
    private TextView t_age;
    private TextView t_room;
    private TextView t_sex;


    public static Context context_takeoverlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_takeoverlist);


        // 상단 환자 정보
        t_code=findViewById(R.id.TOlistPcode);
        t_name=findViewById(R.id.TOlistPname);
        t_age=findViewById(R.id.TolistPage);
        t_room=findViewById(R.id.TOlistProom);
        t_sex=findViewById(R.id.TOlistPsex);

        context_takeoverlist=this;

        recyclerView = findViewById(R.id.recyclerViewTO);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        arrayListTO = new ArrayList<>();

        Intent dintent = getIntent();
        patientkey = "E01348005";//dintent.getExtras().getString("patientkey");
        patientName = dintent.getExtras().getString("patientName");
        database = FirebaseDatabase.getInstance();


        // 상단 환자 정보 데이터
        mDatabaseRef = database.getReference("Patient_1").child(patientkey).child("Pt_info");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                PatientInfo patientInfo = snapshot.getValue(PatientInfo.class);
                t_code.setText(patientInfo.getPcode());
                tcode=patientInfo.getPcode();
                t_name.setText(patientInfo.getPname());
                tname=patientInfo.getPname();
                t_age.setText(String.valueOf(patientInfo.getPage()));
                tage= String.valueOf(patientInfo.getPage());
                t_room.setText(String.valueOf(patientInfo.getProom()));
                troom=String.valueOf(patientInfo.getProom());
                t_sex.setText(String.valueOf(patientInfo.getPsex()));
                tsex=String.valueOf(patientInfo.getPsex());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                t_code.setText("불러올 수 없음");
            }
        });

        // 인수인계 목록 데이터 불러오기
        databaseReferenceTO = database.getReference("Patient_1/"+patientkey+"/Takeover");
        TOCustomAdapter adapter = new TOCustomAdapter(arrayListTO, this);
        databaseReferenceTO.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                arrayListTO.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    TakeoverInfo takeoverInfo = snapshot.getValue(TakeoverInfo.class);
                    arrayListTO.add(takeoverInfo);
                    Collections.sort(arrayListTO, new TakeoverInfo());
                    adapter.notifyDataSetChanged();
                }
                for(int i=0; i< arrayListTO.size();i++){
                    if(arrayListTO.get(i).getDotime()>nowtime){
                        position=i;
                        break;
                    }
                }
                if(count!=arrayListTO.size()){
                    count=arrayListTO.size();
                    recyclerView.scrollToPosition(position);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Takeoverlist", String.valueOf(databaseError.toException()));
            }
        });
        recyclerView.setAdapter(adapter);
        adapter.setItemClickListener((holder, view, position) -> {
            TakeoverInfo item = adapter.getItem(position);
            //Toast.makeText(getApplicationContext(), position+1+"번 인수인계 선택됨",Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Takeoverlist.this, com.nfu2.Takeover.TakeoverDetail.class);
            intent.putExtra("pkey",item.getPkey());
            intent.putExtra("patientkey", patientkey);
            intent.putExtra("patientName", patientName);
            intent.putExtra("nursekey",nursekey);
            startActivity(intent);
        });
        btn_createtakeover = findViewById(R.id.btn_create);
        btn_createtakeover.setOnClickListener(v -> {
            Intent intent = new Intent(Takeoverlist.this, com.nfu2.Takeover.TakeoverCreate.class);
            intent.putExtra("patientkey",patientkey);
            intent.putExtra("nursekey",nursekey);
            startActivity(intent);
            recyclerView.scrollToPosition(position);
        });

    }
}