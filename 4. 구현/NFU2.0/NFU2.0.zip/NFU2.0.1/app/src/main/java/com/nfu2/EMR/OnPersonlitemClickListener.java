package com.nfu2.EMR;

import android.view.View;

public interface OnPersonlitemClickListener {
    public void OnItemClick(com.nfu2.EMR.CustomAdapter2.CustomViewHolder2 holder, View view, int position);

}
