package com.nfu2.Takeover;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nfu2.R;

import java.util.ArrayList;

public class TOExpandableListAdapter extends RecyclerView.Adapter<TOExpandableListAdapter.ExpandVH> implements TOOnPersonItemClickListener {

    ArrayList<PatientInfo> patientInfoList;
    private Context context;

    TOOnPersonItemClickListener listener;

    public TOExpandableListAdapter(ArrayList<PatientInfo> patientInfoList, Context context) {
        this.patientInfoList = patientInfoList;
        this.context = context;
    }

    @NonNull
    @Override
    public ExpandVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_patient,parent,false);
        return new ExpandVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpandVH holder, int position) {

        PatientInfo patientInfo = patientInfoList.get(position);
        holder.tv_pname.setText(patientInfo.getPname());
        holder.tv_pcode.setText(patientInfo.getPcode());
        holder.tv_psex.setText(patientInfo.getPsex());
        holder.tv_proom.setText(String.valueOf(patientInfo.getProom()));
        holder.tv_page.setText(String.valueOf(patientInfo.getPage()));
        holder.tv_admdt.setText(patientInfo.getAdmdate());
        holder.tv_disdt.setText(patientInfo.getDisdate());

        boolean isExpandable = patientInfoList.get(position).isExpandable();
        holder.expandableLayout.setVisibility(isExpandable ? View.VISIBLE : View.GONE);

    }

    @Override
    public int getItemCount() {
        return patientInfoList.size();
    }

    @Override
    public void OnItemClick(TOCustomAdapter.CustomViewHolder holder, View view, int position) {
        if(listener!=null){
            listener.OnItemClick(holder,view,position);
        }
    }

    public class ExpandVH extends RecyclerView.ViewHolder {

        TextView tv_pcode, tv_pname, tv_psex, tv_proom, tv_page, tv_admdt, tv_disdt;
        ImageButton btn_to;
        LinearLayout linearLayout;
        RelativeLayout expandableLayout;


        public ExpandVH(@NonNull View itemView) {
            super(itemView);

            String nursekey=((TakeoverPList) TakeoverPList.context_main).pkey; // 간호사 키 연결

            tv_pcode = itemView.findViewById(R.id.txtPcode);
            tv_pname = itemView.findViewById(R.id.txtPname);
            tv_psex = itemView.findViewById(R.id.txtsex);
            tv_proom = itemView.findViewById(R.id.txtroom);
            tv_page = itemView.findViewById(R.id.txtage);
            tv_admdt = itemView.findViewById(R.id.txtadmdt);
            tv_disdt = itemView.findViewById(R.id.txtdisdt);

            btn_to = itemView.findViewById(R.id.btnTolist);

            linearLayout = itemView.findViewById(R.id.linear_layout);
            expandableLayout = itemView.findViewById(R.id.expandable_layout);

            linearLayout.setOnClickListener(v -> {
                PatientInfo patientInfo = patientInfoList.get(getAbsoluteAdapterPosition());
                patientInfo.setExpandable(!patientInfo.isExpandable());
                notifyItemChanged(getAbsoluteAdapterPosition());
            });

            btn_to.setOnClickListener(v -> {
                Intent intent = new Intent(context, Takeoverlist.class);
                intent.putExtra("nursekey",nursekey);
                intent.putExtra("patientkey",tv_pcode.getText());
                intent.putExtra("patientName", tv_pname.getText());
                context.startActivity(intent);
            });


        }
    }
}