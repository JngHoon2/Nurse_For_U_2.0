package com.nfu2.EMR;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nfu2.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private com.nfu2.EMR.CustomAdapter2 adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<com.nfu2.EMR.PatientInfo> arrayList;
    private FirebaseDatabase database=FirebaseDatabase.getInstance();
    private DatabaseReference mDatabaseRef = database.getReference();

    public static Context context_main;
    private Object PatientInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context_main=this;

        recyclerView=findViewById(R.id.recyclerView);//id연결
        recyclerView.setHasFixedSize(true);//리사이클러뷰 기존 성능 강화
        layoutManager=new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
        arrayList=new ArrayList<>();//PatientInfo 객체를 담을 어레이 리스트(어댑터쪽으로)

        database=FirebaseDatabase.getInstance();//파이어베이스 데이터베이스 연동
        mDatabaseRef =database.getReference("Patient");//DB 테이블 연결
        mDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //파이어베이스 데이터베이스의 데이터를 받아오는 곳
                arrayList.clear();
                for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                    com.nfu2.EMR.PatientInfo patientInfo = snapshot.child("EMR").getValue(com.nfu2.EMR.PatientInfo.class);//만들어뒀던 User 객체에 데이터를 담는다.
                        arrayList.add(patientInfo);//담은 DB들을 배열리스트에 넣고 리사이클리뷰로 보낼 준비
                    }
                adapter.notifyDataSetChanged();//리스트 저장 및 새로고침
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            //DB를 가져오던 중 에러 발생
            Log.e("MainActivity", String.valueOf(databaseError.toException()));//스트링 형태로 바꿔서 에러를 출력해 준다.

            }
        });

        adapter=new com.nfu2.EMR.CustomAdapter2(arrayList,this);
        recyclerView.setAdapter(adapter);

        context_main = this;
    }
}