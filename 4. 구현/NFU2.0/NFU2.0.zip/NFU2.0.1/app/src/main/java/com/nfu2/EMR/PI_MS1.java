package com.nfu2.EMR;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.nfu2.R;


//test1번째
public class PI_MS1 extends AppCompatActivity {
    protected Button main1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pi_ms1);

        main1=findViewById(R.id.main1);
        main1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(PI_MS1.this, PI_MO2.class);
                startActivity(intent);//액티비티이동
            }
        });



        //들어오는
        //Intent dintent=getIntent();
       //String patientkey = dintent.getExtras().getString("patientkey");//환자코드를  item 텍스트 뷰를->Addpter를 통해서 저장해서 읽어온 것
    }
}