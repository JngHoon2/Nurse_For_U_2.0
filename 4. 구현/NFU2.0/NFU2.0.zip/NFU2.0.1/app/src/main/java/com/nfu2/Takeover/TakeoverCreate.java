package com.nfu2.Takeover;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nfu2.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TakeoverCreate extends AppCompatActivity {

    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
    private TextView textView_Date; // 날짜정보
    private TextView textView_Time; // 시간정보

    private DatePickerDialog.OnDateSetListener callbackMethod;
    private TimePickerDialog.OnTimeSetListener callbackMethod1;

    private EditText editText_content; // 인수인계 내용 Edit

    private ImageButton btn_date, btn_time; // 날짜, 시간 설정 버튼
    private Button btn_save; // 저장버튼

    private String writer=((TakeoverPList) TakeoverPList.context_main).nursename; // 간호사 이름
    private String nursecode;
    private String patientcode;
    private String pkey;
    private String wDate;
    private String modify ="";
    private String mdate="";
    private long dotime;

    // 상단 환자 정보
    private TextView t_code;
    private TextView t_name;
    private TextView t_age;
    private TextView t_room;
    private TextView t_sex;

    // 패널 위 작성자, 작성일
    private TextView t_date;
    private TextView t_writer;

    // 패널 위 체크이미지
    private ImageView CR_check;
    private int cnt;

    // 간호사 코드, 이름
    public String nursekey = ((TakeoverPList) TakeoverPList.context_main).pkey;
    public String nursename=((TakeoverPList) TakeoverPList.context_main).nursename;

    private void writeNewTO(String pkey, String writer, long dotime, String date, String time, String content, boolean check, String modify, String mdate) {
        TakeoverInfo to = new TakeoverInfo(pkey, writer, wDate, dotime, date, time, content, check, modify, mdate);
        mDatabase.child("Patient_1").child(patientcode).child("Takeover").child(pkey).setValue(to);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_takeover_create);

        cnt = 0;


        this.InitializeView();
        this.InitializeListener();

        // 넘겨받은 환자코드, 간호사 코드
        Intent modify_intent = getIntent();
        patientcode = modify_intent.getExtras().getString("patientkey");
        nursecode = modify_intent.getExtras().getString("nursekey");

        // Button 연결(날짜 설정, 시간 설정, 저장)
        btn_date=(ImageButton)findViewById(R.id.btn_date);
        btn_time=(ImageButton)findViewById(R.id.btn_time);
        btn_save=(Button)findViewById(R.id.btn_save);

        // Textview 연결(상단환자 정보) - takeoverlist에서 가져옴
        t_code=findViewById(R.id.TOcreatePcode);
        t_code.setText(((Takeoverlist)Takeoverlist.context_takeoverlist).tcode);
        t_name=findViewById(R.id.TOcreatePname);
        t_name.setText(((Takeoverlist)Takeoverlist.context_takeoverlist).tname);
        t_age=findViewById(R.id.TocreatePage);
        t_age.setText(((Takeoverlist)Takeoverlist.context_takeoverlist).tage);
        t_sex=findViewById(R.id.TOcreatePsex);
        t_sex.setText(((Takeoverlist)Takeoverlist.context_takeoverlist).tsex);
        t_room=findViewById(R.id.TOcreateProom);
        t_room.setText(((Takeoverlist)Takeoverlist.context_takeoverlist).troom);

        // Textview 연결(인수인계목록 상단 작성일, 작성자)
        t_date=findViewById(R.id.CRtodate);
        t_writer=findViewById(R.id.CRregister);

        // 패널 위 체크 이미지
        CR_check = findViewById(R.id.CR_ivcheck);

        // 패널 위 현재 날짜, 간호사 이름 Textview 설정
        long currenttime = System.currentTimeMillis();
        Date cuDate = new Date(currenttime);
        SimpleDateFormat simplewDate = new SimpleDateFormat("yyyy. MM. dd.");
        String wDate =  simplewDate.format(cuDate);
        t_date.setText(wDate);
        t_writer.setText(String.valueOf(nursename));

        btn_save.setOnClickListener(v -> {
            if(textView_Date.getText().equals("수행시간을 설정해주세요")||textView_Time.getText().equals("")||editText_content.getText().length()==0){
                Toast.makeText(getApplicationContext(), "누락된 정보가 있습니다.",Toast.LENGTH_SHORT).show();
            }
            else{
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("신규 항목");
                builder.setMessage("저장하시겠습니까?");
                builder.setPositiveButton("예", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String getDate = textView_Date.getText().toString();
                        String getTime = textView_Time.getText().toString();
                        String getContent = editText_content.getText().toString();

                        String str1[]=getDate.split("월 |일");
                        String str2[]=getTime.split("시 |분");

                        long now = System.currentTimeMillis();
                        Date mDate = new Date(now);
                        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyyMMddHHmmss");
                        SimpleDateFormat simpleDate2 = new SimpleDateFormat("yyyy. MM. dd.");
                        pkey = simpleDate.format(mDate);
                        dotime=Long.parseLong(pkey.substring(0,4)+str1[0]+str1[1]+str2[0]+str2[1]);
                        writeNewTO(pkey, writer, dotime,getDate,getTime,getContent,false,modify,mdate);
                        Toast.makeText(getApplicationContext(), "저장되었습니다.",Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                builder.setNegativeButton("아니오",null);
                builder.create().show();
            }
        });
    }

    public void InitializeView()
    {
        textView_Date = (TextView)findViewById(R.id.tv_date);
        textView_Time = (TextView)findViewById(R.id.tv_time);
        editText_content = (EditText)findViewById(R.id.et_write);
    }

    public void InitializeListener()
    {
        callbackMethod = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                int month1=month+1;
                String m="";
                String d="";
                if (Integer.toString(month1).length()==1){
                    m="0"+Integer.toString(month1);
                }
                else{
                    m=Integer.toString(month1);
                }
                if (Integer.toString(dayOfMonth).length()==1){
                    d="0"+Integer.toString(dayOfMonth);
                }
                else{
                    d=Integer.toString(dayOfMonth);
                }
                textView_Date.setText(m+"월 "+d+"일");
                cnt += 1;
                if(cnt >= 2){
                    CR_check.setBackgroundResource(R.drawable.cr_checko);
                }
            }
        };
        callbackMethod1 = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String h="";
                String m="";
                if (Integer.toString(hourOfDay).length()==1){
                    h="0"+Integer.toString(hourOfDay);
                }
                else{
                    h=Integer.toString(hourOfDay);
                }
                if (Integer.toString(minute).length()==1){
                    m="0"+Integer.toString(minute);
                }
                else{
                    m=Integer.toString(minute);
                }
                textView_Time.setText(h + "시 " + m + "분");
                cnt+=1;
                if(cnt >= 2){
                    CR_check.setBackgroundResource(R.drawable.cr_checko);
                }
            }
        };
    }

    public void OnClickHandler(View view){
        Calendar cal = Calendar.getInstance();
        if(view==btn_date){
            new DatePickerDialog(this, callbackMethod, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE)).show();
        }
        if(view==btn_time){
            new TimePickerDialog(this, callbackMethod1, cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE), true).show();
        }
    }

}