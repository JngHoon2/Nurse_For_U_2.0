package com.nfu2.Login;

public class UserInfo {
    private String name;
    private String position;
    private String userCode;
    private String team;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getUserCode() { return userCode; }
    public void setUserCode(String userCode) { this.userCode = userCode; }

    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }
}
