package com.nfu2.Takeover;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nfu2.R;

import java.util.ArrayList;

public class TakeoverPList extends AppCompatActivity {
    private com.nfu2.Takeover.BackPressCloseHandler backPressCloseHandler; // 뒤로가기 버튼


    private RecyclerView recyclerView;
    private ArrayList<com.nfu2.Takeover.PatientInfo> arrayList2;
    private FirebaseDatabase database =FirebaseDatabase.getInstance();
    private DatabaseReference databaseRef = database.getReference();
    private TextView mtxtWard, mtxtTeam, mtxtNurse, mtxtNpt;
    private com.nfu2.Takeover.TOExpandableListAdapter adapter;

    public String pkey;
    public String nursename, nurseteam, nurseward;
    public static Context context_main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_ptlist);

        context_main = this;

        //ActionBar actionBar = getSupportActionBar();
        //actionBar.hide(); //상단바 감춤

        //상단 간호사 정보 변수
        mtxtNurse = findViewById(R.id.Nnurse);
        mtxtTeam = findViewById(R.id.Nteam);
        mtxtWard = findViewById(R.id.Nward);
        mtxtNpt = findViewById(R.id.Npt);

        //값 넘겨받기 Login에서 받아옴
        /*Intent dintent = getIntent();
        Bundle bundle = dintent.getExtras();*/
        pkey = "12321412"; // 여기 넘겨받아야함!~!~!~!~!


        //상단 간호사 데이터
        databaseRef = database.getReference("Nurse").child("Nurcode").child(pkey);
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                com.nfu2.Takeover.NurseInfo nurseInfo = snapshot.getValue(com.nfu2.Takeover.NurseInfo.class);
                mtxtNurse.setText(nurseInfo.getNname()); // 상단 간호사 이름
                mtxtWard.setText(nurseInfo.getNward()); // 상단 간호사 병동
                mtxtTeam.setText(nurseInfo.getNteam()); // 상단 간호사 팀
                nursename=mtxtNurse.getText().toString();
                nurseteam=mtxtTeam.getText().toString();
                nurseward=mtxtWard.getText().toString();

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        recyclerView = findViewById(R.id.recyclerView); // id연결

        arrayList2 = new ArrayList<>(); // PatientInfo 객체를 담을 어레이 리스트(어댑터쪽으로)

        databaseRef = database.getReference("Patient_1");
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                // 파이어베이스 데이터베이스의 데이터를 받아오는 부분
                arrayList2.clear(); // 기존 배열 초기화
                for (DataSnapshot snapshot : datasnapshot.getChildren()) {
                    com.nfu2.Takeover.PatientInfo patientInfo = snapshot.child("Pt_info").getValue(com.nfu2.Takeover.PatientInfo.class); // 만들어놓은 PatientInfo 객체에 데이터를 넣는다.
                    arrayList2.add(patientInfo); // 담은 데이터를 배열리스트에 넣고 리사이클러로 보낼 준비
                    mtxtNpt.setText(String.valueOf(arrayList2.size())); // 담당환자 인원수 계산
                }
                adapter.notifyDataSetChanged(); // 리스트 저장 및 새로고침
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // 디비를 가져오던 중 에러 발생 시
                Log.e("MainActivity", String.valueOf(databaseError.toException()));
            }
        });

        adapter = new com.nfu2.Takeover.TOExpandableListAdapter(arrayList2, context_main);
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);

        mtxtNpt.setText(String.valueOf(adapter.getItemCount()));

        backPressCloseHandler = new com.nfu2.Takeover.BackPressCloseHandler(this); // 뒤로가기버튼(앱종료)


    }
    @Override
    public void onBackPressed(){
        backPressCloseHandler.onBackPressed();
    }
}