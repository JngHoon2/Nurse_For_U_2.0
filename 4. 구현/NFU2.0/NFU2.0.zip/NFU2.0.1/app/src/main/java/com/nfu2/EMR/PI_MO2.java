package com.nfu2.EMR;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.nfu2.R;

public class PI_MO2 extends AppCompatActivity{
    private Button main2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pi_mo2);

        main2=findViewById(R.id.main2);
        main2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(PI_MO2.this, PI_PACS3.class);
                startActivity(intent);//액티비티이동
            }
        });
        //들어오는
        //Intent dintent=getIntent();
        //String patientkey = dintent.getExtras().getString("patientkey");//환자코드를  item있는 텍스트 뷰를->Addpter를 통해서 저장해서 읽어온 것
    }
}