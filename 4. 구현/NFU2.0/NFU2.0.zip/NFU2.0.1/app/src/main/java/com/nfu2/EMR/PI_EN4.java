package com.nfu2.EMR;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.nfu2.R;

public class PI_EN4 extends AppCompatActivity {
    private Button main4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pi_mn4);

       main4=findViewById(R.id.main4);
       main4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(PI_EN4.this, com.nfu2.EMR.PI_MS1.class);

                startActivity(intent);//액티비티이동
            }
        });

        //들어오는
        //Intent dintent=getIntent();
        //String patientkey = dintent.getExtras().getString("patientkey");//환자코드를  item있는 텍스트 뷰를->Addpter를 통해서 저장해서 읽어온 것
    }
}