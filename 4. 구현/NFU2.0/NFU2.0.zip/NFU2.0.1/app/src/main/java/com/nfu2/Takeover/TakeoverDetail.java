package com.nfu2.Takeover;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nfu2.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class TakeoverDetail extends AppCompatActivity {

    // 상단 환자 정보
    private TextView t_code;
    private TextView t_name;
    private TextView t_age;
    private TextView t_room;
    private TextView t_sex;

    // 세부사항 정보
    private TextView txt_w_time; // 작성시간
    private TextView txt_d_time; // 수행시간
    private TextView txt_writer; // 작성자

    // 수정자 정보
    private TextView txt_m_time; // 수정시간
    private TextView txt_modify; // 수정자
    private TextView txt_nursecan; // "간호사"텍스트 (깡통)

    // 수정 Editview
    private EditText edt_content;

    // 수정화면으로 변경위한 layouts
    private LinearLayout layout_default;
    private LinearLayout layout_modify;

    // 버튼 정의
    private Button btn_modify; // 수정 버튼
    private Button btn_delete; // 삭제 버튼
    private Button btn_doModify; // 수정완료 버튼

    // 변수 정의
    private String w_time = "";
    private String d_time = "";
    private String d_time_date = "";
    private String d_time_hour = "";
    private String writer = "";
    private String content = "";
    private String save_d_time = "";
    private String save_content = "";
    private boolean bln_dt_check;

    private String modify;
    private String m_time;

    // 아래 두줄은 이전 페이지로 부터 값을 받아와야하는 변수들입니다.
    private String patientKey;
    private String takeOverNum = "";
    private String nurseKey = "";

    // 수정자, 수정 시간
    private String modifydb;
    private String m_timedb;

    // 세부사항 완료여부
    CheckBox dt_check;

    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private DatabaseReference mDatabaseRef;
    private DatabaseReference wDatabaseRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_takeover_detail);

        // 상단바 감추기

        t_code=findViewById(R.id.TODetailPcode);
        t_name=findViewById(R.id.TODetailPname);
        t_age=findViewById(R.id.TODetailPage);
        t_room=findViewById(R.id.TODetailProom);
        t_sex=findViewById(R.id.TODetailPsex);

        txt_w_time = findViewById(R.id.txt_w_time);
        txt_d_time = findViewById(R.id.txt_d_time);
        txt_m_time = findViewById(R.id.txt_m_time);

        txt_writer = findViewById(R.id.txtDTwriter);
        txt_modify = findViewById(R.id.txtDTmodify);
        txt_nursecan = findViewById(R.id.Nursecan);
        edt_content = findViewById(R.id.txt_content);

        layout_default = findViewById(R.id.layout_default);
        layout_modify = findViewById(R.id.layout_modify);

        btn_modify = findViewById(R.id.btn_modify);
        btn_delete = findViewById(R.id.btn_delete);
        btn_doModify = findViewById(R.id.btn_doModify);

        dt_check = findViewById(R.id.Detail_cb);


        Intent dintent = getIntent();
        patientKey = dintent.getExtras().getString("patientkey");
        takeOverNum = dintent.getExtras().getString("pkey");
        nurseKey = dintent.getExtras().getString("nursekey"); // 간호사 키 연결

        database = FirebaseDatabase.getInstance();

        // 상단 환자 정보 데이터
        mDatabaseRef = database.getReference("Patient_1").child(patientKey).child("Pt_info");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                PatientInfo patientInfo = snapshot.getValue(PatientInfo.class);
                t_code.setText(patientInfo.getPcode());
                t_name.setText(patientInfo.getPname());
                t_age.setText(String.valueOf(patientInfo.getPage()));
                t_room.setText(String.valueOf(patientInfo.getProom()));
                t_sex.setText(String.valueOf(patientInfo.getPsex()));
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                t_code.setText("불러올 수 없음");
            }
        });

        wDatabaseRef = database.getReference().child("Nurse").child("Nurcode").child(nurseKey);
        wDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                modifydb = snapshot.child("Nname").getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        databaseReference = database.getReference().child("Patient_1").child(patientKey).child("Takeover").child(takeOverNum);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // 데이터베이스에서 인수인계 세부내용(content)를 불러와 txt_content로 출력합니다.
                content = snapshot.child("content").getValue(String.class);
                edt_content.setText(content);

                // 데이터베이스에서 인수인계 작성자(인계자/writer)를 불러와 txt_writer로 출력합니다.
                writer = snapshot.child("writer").getValue(String.class);
                txt_writer.setText(writer);

                // 데이터베이스에서 수정자를 불러와 txt_modify로 출력
                modify = snapshot.child("modify").getValue(String.class);
                if(modify == ""){
                    txt_modify.setVisibility(View.INVISIBLE);
                    txt_m_time.setVisibility(View.INVISIBLE);
                    txt_nursecan.setVisibility(View.INVISIBLE);
                }
                else{
                    txt_modify.setText(modify);
                }

                // 데이터베이스에서 수정시간을 불러옴
                m_time = snapshot.child("mdate").getValue(String.class);
                txt_m_time.setText(m_time);

                // 데이터베이스에서 완료여부를 불러옴
                /*bln_dt_check = snapshot.child("check").getValue(Boolean.class);
                dt_check.setChecked(bln_dt_check);*/

                // 아래 try-catch 문은 작성 일시의 형변환을 위해 적성된 코드입니다.
                try {
                    w_time = snapshot.child("pkey").getValue(String.class);
                    SimpleDateFormat beforeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                    SimpleDateFormat afterFormat = new SimpleDateFormat("yyyy년  MM월 dd일  HH시 mm분");
                    Date beforeDate = beforeFormat.parse(w_time);
                    w_time = afterFormat.format(beforeDate);

                    txt_w_time.setText(w_time);
                }
                catch (Exception e)
                {
                    txt_w_time.setText("작성 일시 오류");
                }

                try
                {
                    d_time_hour = snapshot.child("time").getValue(String.class);
                    d_time_date = snapshot.child("date").getValue(String.class);

                    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
                    Date getyear = new Date();
                    String d_time_year = yearFormat.format(getyear);
                    d_time = d_time_year + "년  " + d_time_date + "  " + d_time_hour;
                    txt_d_time.setText(d_time);
                }
                catch(Exception e)
                {
                    txt_d_time.setText("수행 일시 오류");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("load data error", String.valueOf(error.toException()));

            }
        });

        // 삭제버튼 클릭 시 발생되는 이벤트입니다.
        btn_delete.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("인수인계 항목 삭제");
            builder.setMessage("해당 항목을 삭제하시겠습니까?");
            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    try
                    {
                        // 항목을 데이터베이스에서 삭제합니다.
                        databaseReference.removeValue();

                        // 항목이 삭제되었음을 토스트메시지를 통해 알리고 액티비티를 종료합니다.
                        Toast.makeText(getApplicationContext(), "항목이 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    catch(Exception e)
                    {
                        Log.e("delete data error", e.toString());
                        Toast.makeText(getApplicationContext(), "삭제 실패", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            builder.setNegativeButton("취소", null);
            builder.create().show();
        });

        // 수정버튼 클릭 시 발생되는 이벤트입니다.
        btn_modify.setOnClickListener(v -> {
            // 수정버튼과 삭제버튼을 비활성화하고 수정완료버튼을 활성화합니다.
            layout_default.setVisibility(View.INVISIBLE);
            layout_modify.setVisibility(View.VISIBLE);

            // 수행 일시와 내용을 변경할 수 있게 합니다.
            txt_d_time.setFocusableInTouchMode(true);
            edt_content.setFocusableInTouchMode(true);

            // 수정 시 작성칸, 수행시간 텍스트 색상 변경
            edt_content.setTextColor(Color.parseColor("#086dd1"));
            txt_d_time.setTextColor(Color.parseColor("#086dd1"));

            // 수정 취소를 대비하여 기존내역을 임시 저장합니다.
            save_d_time = txt_d_time.getText().toString();
            save_content = edt_content.getText().toString();
            // 변경 가능한 내용을 설명합니다.
            Toast.makeText(getApplicationContext(), "수행 일시와 내용을 변경할 수 있습니다.", Toast.LENGTH_SHORT).show();
        });

        // 수정완료버튼 클릭 시 발생되는 이벤트입니다.
        btn_doModify.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("인수인계 항목 수정");
            builder.setMessage("정말로 수정하시겠습니까?");
            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    try
                    {
                        // 실제로 데이터가 업데이트되는 부분
                        Map<String, Object> update_object = new HashMap<String, Object>();
                        update_object.put("content", edt_content.getText().toString());
                        String datesum = txt_d_time.getText().toString();
                        String datesum2 = datesum.replaceAll("[^0-9]","");

                        // 현재 수정시간 put
                        long now = System.currentTimeMillis();
                        Date mDate = new Date(now);
                        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy년  MM월 dd일  HH시 mm분");
                        m_timedb = simpleDate.format(mDate);

                        update_object.put("mdate", m_timedb);
                        update_object.put("modify", modifydb);
                        update_object.put("date",datesum2.substring(4,6)+"월 "+datesum2.substring(6,8)+"일");
                        update_object.put("time", datesum2.substring(8,10)+"시 "+datesum2.substring(10,12)+"분");
                        update_object.put("dotime",Long.parseLong(datesum2));
                        databaseReference.updateChildren(update_object);

                        layout_default.setVisibility(View.VISIBLE);
                        layout_modify.setVisibility(View.INVISIBLE);

                        txt_d_time.setFocusable(false);
                        edt_content.setFocusable(false);

                        txt_d_time.setFocusableInTouchMode(false);
                        edt_content.setFocusableInTouchMode(false);

                        // 작성칸, 수행시간 텍스트 색상 되돌리기
                        edt_content.setTextColor(Color.parseColor("#48494a"));
                        txt_d_time.setTextColor(Color.parseColor("#48494a"));

                        // 수정시간, 수정자 텍스트 새로고침
                        txt_m_time.invalidate();
                        txt_modify.invalidate();

                        Toast.makeText(getApplicationContext(), "수정이 반영되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                    catch(Exception e)
                    {
                        Log.e("update data error", e.toString());
                        Toast.makeText(getApplicationContext(), "업데이트 실패", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            builder.setNegativeButton("수정계속", null);
            builder.setNeutralButton("수정취소", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    layout_default.setVisibility(View.VISIBLE);
                    layout_modify.setVisibility(View.INVISIBLE);

                    txt_d_time.setText(save_d_time);
                    edt_content.setText(save_content);

                    txt_d_time.setFocusable(false);
                    edt_content.setFocusable(false);

                    txt_d_time.setFocusableInTouchMode(false);
                    edt_content.setFocusableInTouchMode(false);
                }
            });
            builder.create().show();
        });
    }
}