package com.nfu2.EMR;

public class PatientInfo {
    private String pname;
    private String pcode;
    private String psex;
    private int page;
    private int proom;
    private String pHD;
    //private String ncode1;
    //private String ncode2;


    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPcode() {
        return pcode;
    }

    public void setPcode(String pcode) {
        this.pcode = pcode;
    }

    public String getPsex() {
        return psex;
    }

    public void setPsex(String psex) {
        this.psex = psex;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getProom() {
        return proom;
    }

    public void setProom(int proom) {
        this.proom = proom;
    }

    public String getpHD() {
        return pHD;
    }

    public void setpHD(String pHD) {
        this.pHD = pHD;
    }


}
