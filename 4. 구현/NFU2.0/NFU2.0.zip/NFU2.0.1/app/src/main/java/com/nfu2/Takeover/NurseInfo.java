package com.nfu2.Takeover;

public class NurseInfo {
    private String Nname; // 간호사 이름
    private String Nteam; // 간호사 팀
    private String Nward; // 간호사 병동
    private int Npt; // 간호사 담당환자

    public int getNpt() {
        return Npt;
    }

    public void setNpt(int npt) {
        Npt = npt;
    }



    public String getNname() { return Nname; }

    public void setNname(String nname) { Nname = nname; }

    public String getNteam() {
        return Nteam;
    }

    public void setNteam(String nteam) {
        Nteam = nteam;
    }

    public String getNward() {
        return Nward;
    }

    public void setNward(String nward) {
        Nward = nward;
    }

}
