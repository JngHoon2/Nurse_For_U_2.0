package com.nfu2.Injection;

import android.view.View;

public interface OnPersonItemClickListener {
    public void OnItemClick(com.nfu2.Injection.CustomAdapterIJ.CustomViewHolderIJ holder, View view, int position);
}
