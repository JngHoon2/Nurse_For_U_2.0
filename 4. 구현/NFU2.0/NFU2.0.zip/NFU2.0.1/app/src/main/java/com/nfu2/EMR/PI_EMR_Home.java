package com.nfu2.EMR;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.nfu2.R;

public class PI_EMR_Home extends AppCompatActivity {
    private CardView main0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pi_emr_list);

        main0=findViewById(R.id.mein0);
        main0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(PI_EMR_Home.this, PI_MS1.class);

                startActivity(intent);//액티비티이동
            }
        });

        //들어오는
        //Intent dintent=getIntent();
        //String patientkey = dintent.getExtras().getString("patientkey");//환자코드를  item있는 텍스트 뷰를->Addpter를 통해서 저장해서 읽어온 것
    }
}
