package com.nfu2.EMR;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nfu2.R;

import java.util.ArrayList;

public class CustomAdapter2 extends RecyclerView.Adapter<CustomAdapter2.CustomViewHolder2> implements com.nfu2.EMR.OnPersonlitemClickListener{

    private ArrayList<com.nfu2.EMR.PatientInfo> arrayList;
    private Context context;

    com.nfu2.EMR.OnPersonlitemClickListener listener;

    public CustomAdapter2(ArrayList<com.nfu2.EMR.PatientInfo> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }
    @NonNull
    @Override
    public CustomViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.pi_emr_list,parent,false);
        return new CustomViewHolder2(itemView,this);
    }
    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder2 holder, int position) {

        // 데이터 불러오기
        Glide.with(holder.itemView);
        holder.tv_name.setText(arrayList.get(position).getPname());
        holder.tv_code.setText(arrayList.get(position).getPcode());
        holder.tv_sex.setText(arrayList.get(position).getPsex());
        holder.tv_room.setText(String.valueOf(arrayList.get(position).getProom()));
        holder.tv_age.setText(String.valueOf(arrayList.get(position).getPage()));
        holder.tv_HD.setText(arrayList.get(position).getpHD());

    }
    @Override
    public int getItemCount() {
        return (arrayList!=null?arrayList.size():0);
    }

    @Override
    public void OnItemClick(CustomViewHolder2 holder, View view, int position) {
        if(listener!=null){
            listener.OnItemClick(holder,view,position);
        }
    }
    public class CustomViewHolder2 extends RecyclerView.ViewHolder{
        TextView tv_name;
        TextView tv_code;
        TextView tv_sex;
        TextView tv_room;
        TextView tv_age;
        TextView tv_HD;

        LinearLayout linearLayout;

        public CustomViewHolder2(@NonNull View itemView, OnPersonlitemClickListener listener) {
            super(itemView);
            //String nursekey=((MainActivity) MainActivity.context_main).pkey; //****
            this.tv_name=itemView.findViewById(R.id.tv_id);
            this.tv_code=itemView.findViewById(R.id.txtPcode);
            this.tv_room=itemView.findViewById(R.id.txtProom);
            this.tv_sex=itemView.findViewById(R.id.txtPsex);
            this.tv_HD=itemView.findViewById(R.id.txtPHD);
            this.tv_age=itemView.findViewById(R.id.txtPage);

            linearLayout = itemView.findViewById(R.id.Cardview);

            linearLayout.setOnClickListener(view -> {
                Intent intent = new Intent(context, com.nfu2.EMR.PI_MS1.class);
                intent.putExtra("patientkey", tv_code.getText());
                context.startActivity(intent);
            });


        }
    }
}