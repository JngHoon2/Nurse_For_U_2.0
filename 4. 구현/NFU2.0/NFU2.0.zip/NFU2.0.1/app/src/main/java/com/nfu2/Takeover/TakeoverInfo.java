package com.nfu2.Takeover;

import java.util.Comparator;

public class TakeoverInfo implements Comparator<TakeoverInfo> {
    private String pkey;
    private long dotime;
    private String date; // 수행시간
    private String wdate; // 작성시간
    private String writer; // 작성자
    private String time;
    private String content;

    //수정자 저장
    private String modify; // 수정자
    private String mdate; // 수정시간
    private boolean check;

    public TakeoverInfo(){}

    public String getModify() {
        return modify;
    }

    public void setModify(String modify) {
        this.modify = modify;
    }

    public String getMdate() {
        return mdate;
    }

    public void setMdate(String mdate) {
        this.mdate = mdate;
    }

    public String getWdate() {
        return wdate;
    }
    public void setWdate(String wdate) {
        this.wdate = wdate;
    }

    public String getPkey() { return pkey; }
    public void setPkey(String pkey) { this.pkey = pkey; }

    public String getWriter() { return writer; }
    public void setWriter() { this.writer = writer; }

    public long getDotime() { return dotime; }
    public void setDotime() { this.dotime=dotime; }

    public String getDate() { return date; }
    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public boolean getCheck(){ return check; }
    public void setCheck(boolean check) { this.check = check; }

    public TakeoverInfo(String pkey, String writer, String wdate, long dotime, String date, String time, String content, boolean check, String modify, String mdate){
        this.pkey=pkey;
        this.writer=writer;
        this.dotime=dotime;
        this.date=date;
        this.time=time;
        this.content=content;
        this.check=check;
        this.mdate=mdate;
        this.modify=modify;
    }

    @Override
    public int compare(TakeoverInfo o1, TakeoverInfo o2) {
        if(o1.getDotime()>o2.getDotime()){
            return 1;
        }
        else if(o1.getDotime()<o2.getDotime()){
            return -1;
        }
        return 0;
    }
}