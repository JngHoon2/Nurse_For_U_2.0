package com.nfu2.Takeover;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nfu2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class TOCustomAdapter extends RecyclerView.Adapter<TOCustomAdapter.CustomViewHolder> implements com.nfu2.Takeover.TOOnPersonItemClickListener {

    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
    ArrayList<com.nfu2.Takeover.TakeoverInfo> arrayListTO;
    private Context context;
    com.nfu2.Takeover.TOOnPersonItemClickListener listener;

    //현재시간
    long now = System.currentTimeMillis();
    Date mDate = new Date(now);
    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyyMMddHHmm");
    private String ntime = simpleDateFormat.format(mDate);
    private long nowtime = Long.parseLong(ntime);

    public TOCustomAdapter(ArrayList<com.nfu2.Takeover.TakeoverInfo> arrayListTO, Context context) {
        this.arrayListTO = arrayListTO;
        this.context = context;
    }
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.list_item_takeover,parent,false);
        return new CustomViewHolder(itemView,this::OnItemClick);
    }
    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        com.nfu2.Takeover.TakeoverInfo item = arrayListTO.get(position);
        holder.setItem(item);
    }
    @Override
    public int getItemCount() {
        return arrayListTO.size();
    }
    @Override
    public void OnItemClick(CustomViewHolder holder, View view, int position) {
        if(listener!=null){
            listener.OnItemClick(holder, view, position);
        }
    }
    public void setItemClickListener(com.nfu2.Takeover.TOOnPersonItemClickListener listener){
        this.listener=listener;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener{
        TextView tv_wdate;
        TextView tv_writer;

        TextView tv_date;
        TextView tv_time;
        TextView tv_content;
        CheckBox cb_check;

        CardView cv_list;

        CustomViewHolder(@NonNull View itemView, com.nfu2.Takeover.TOOnPersonItemClickListener listener) {
            super(itemView);
            this.tv_wdate = itemView.findViewById(R.id.txtTodate);
            this.tv_writer = itemView.findViewById(R.id.txtToregister);

            this.tv_date = itemView.findViewById(R.id.tv_date);
            this.tv_time = itemView.findViewById(R.id.tv_time);
            this.tv_content = itemView.findViewById(R.id.tv_content);
            this.cb_check = itemView.findViewById(R.id.cb_check);
            this.cv_list = itemView.findViewById(R.id.PtlistCardview);

            this.cb_check.setOnCheckedChangeListener(this::onCheckedChanged);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAbsoluteAdapterPosition();
                    if(listener !=null){
                        listener.OnItemClick(CustomViewHolder.this,v, position);
                    }
                }
            });
        }
        public void setItem(com.nfu2.Takeover.TakeoverInfo item){
            if(nowtime>=item.getDotime()){
                this.cv_list.setBackgroundResource(R.drawable.lasttime);
                this.cb_check.setEnabled(false);
            }
            else{
                this.cv_list.setBackgroundResource(R.drawable.takeoverborder);
                this.cb_check.setEnabled(true);
            }
            String datesum = item.getPkey();
            String datesum2 = datesum.replaceAll("[^0-9]","");
            String w_date_list = datesum2.substring(0,4)+". " + datesum2.substring(4,6)+". "
                    +datesum2.substring(6,8)+".";


            tv_wdate.setText(w_date_list);
            tv_writer.setText(item.getWriter());

            tv_date.setText(item.getDate());
            tv_time.setText(item.getTime());
            tv_content.setText(item.getContent());
            cb_check.setChecked(item.getCheck());
        }
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            String nursekey=((com.nfu2.Takeover.TakeoverPList) com.nfu2.Takeover.TakeoverPList.context_main).pkey; //간호사 코드 받아오는 부분(Test라서 지움)
            String patientkey="E01348005";//((com.nfu2.Takeover.Takeoverlist) com.nfu2.Takeover.Takeoverlist.context_takeoverlist).patientkey;
            if(buttonView.isChecked()==true){
                buttonView.setText("완료");
                int p = getAbsoluteAdapterPosition();
                getItem(p).setCheck(true);
                mDatabase.child("Patient_1").child(patientkey).child("Takeover").child(getItem(p).getPkey()).setValue(getItem(p));
            }
            else if(buttonView.isChecked()==false){
                buttonView.setText("");
                int p = getAbsoluteAdapterPosition();
                getItem(p).setCheck(false);
                mDatabase.child("Patient_1").child(patientkey).child("Takeover").child(getItem(p).getPkey()).setValue(getItem(p));
            }
        }
    }
    public com.nfu2.Takeover.TakeoverInfo getItem(int position){
        return arrayListTO.get(position);
    }
}