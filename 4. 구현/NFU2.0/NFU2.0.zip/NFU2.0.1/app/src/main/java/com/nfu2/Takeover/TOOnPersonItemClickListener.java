package com.nfu2.Takeover;

import android.view.View;

public interface TOOnPersonItemClickListener {
    public void OnItemClick(TOCustomAdapter.CustomViewHolder holder, View view, int position);
}
