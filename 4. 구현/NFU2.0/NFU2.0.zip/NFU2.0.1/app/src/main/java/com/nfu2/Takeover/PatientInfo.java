package com.nfu2.Takeover;

public class PatientInfo {
    private String pcode;
    private String pname;
    private String psex;
    private int proom;
    private int page;
    private String admdate;
    private String disdate;

    public boolean isExpandable() {
        return expandable;
    }

    public void setExpandable(boolean expandable) {
        this.expandable = expandable;
    }

    private boolean expandable;

    public PatientInfo(){
        /*this.pcode = pcode;
        this.pname = pname;
        this.psex = psex;
        this.proom = proom;
        this.page = page;
        this.admdate = admdate;
        this.disdate = disdate;
        this.expandable = false;*/
    }

    public String getPcode() {
        return pcode;
    }

    public void setPcode(String pcode) {
        this.pcode = pcode;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPsex() {
        return psex;
    }

    public void setPsex(String psex) {
        this.psex = psex;
    }

    public int getProom() {
        return proom;
    }

    public void setProom(int proom) {
        this.proom = proom;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getAdmdate() {
        return admdate;
    }

    public void setAdmdate(String admdate) {
        this.admdate = admdate;
    }

    public String getDisdate() {
        return disdate;
    }

    public void setDisdate(String disdate) {
        this.disdate = disdate;
    }
}
