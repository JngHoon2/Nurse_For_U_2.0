package com.nfu2.Injection;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.nfu2.R;

public class INJECTIONDETAIL extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_injectiondetail);
    }
}