package com.nfu2.Login;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.nfu2.R;

public class Login extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_login);
    }
}
