package com.nfu2.Takeover;

public class Takeover {
}
