package com.nfu2.EMR;

public class EMR {
}
