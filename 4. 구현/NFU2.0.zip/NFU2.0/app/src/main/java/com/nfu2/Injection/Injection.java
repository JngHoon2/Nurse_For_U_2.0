package com.nfu2.Injection;

public class Injection {
}
